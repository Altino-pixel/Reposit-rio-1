import sys
import json

def analyze_sensitivity(config):
    # Simulação de análise por IA usando Python
    # Verifica equilíbrio de sensibilidade entre miras
    geral = config.get('geral', 0)
    redDot = config.get('redDot', 0)
    
    recommendation = "Configuração equilibrada."
    if geral > 150 and redDot < 50:
        recommendation = "Sua sensibilidade Geral está muito alta comparada à Red Dot. Isso pode causar trepidação."
    elif geral < 50:
        recommendation = "Sensibilidade muito baixa. Recomenda-se aumentar para melhorar a velocidade de rotação."
    
    return {
        "status": "success",
        "analysis": recommendation,
        "engine": "Python 3.10 Analyzerv1"
    }

if __name__ == "__main__":
    try:
        input_data = json.loads(sys.stdin.read())
        result = analyze_sensitivity(input_data)
        print(json.dumps(result))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}))
