package com.venera.auxilio;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;

@CapacitorPlugin(name = "VeneraSystem")
public class VeneraSystemPlugin extends Plugin {

    static {
        System.loadLibrary("venera_native");
    }

    public native float calculateStabilization(float raw_sens, float jitter_factor);
    public native float calculateMagnetism(float dist, float strength);
    public native String getCoreVersion();

    @PluginMethod
    public void checkShizuku(PluginCall call) {
        // Simulação de detecção do serviço Shizuku
        // Em um app real, usaríamos a Shizuku API (rikka.shizuku)
        JSObject ret = new JSObject();
        ret.put("isActive", true); 
        call.resolve(ret);
    }

    @PluginMethod
    public void getNativeCoreInfo(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("version", getCoreVersion());
        call.resolve(ret);
    }

    @PluginMethod
    public void stabilizeSens(PluginCall call) {
        Float raw = call.getFloat("raw");
        Float jitter = call.getFloat("jitter");
        if (raw == null || jitter == null) {
            call.reject("Parameters required");
            return;
        }
        float stabilized = calculateStabilization(raw, jitter);
        JSObject ret = new JSObject();
        ret.put("stabilized", stabilized);
        call.resolve(ret);
    }

    @PluginMethod
    public void executeShell(PluginCall call) {
        String command = call.getString("command");
        if (command == null) {
            call.reject("Command is required");
            return;
        }

        try {
            Process process = Runtime.getRuntime().exec(command);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            process.waitFor();

            JSObject ret = new JSObject();
            ret.put("output", output.toString());
            ret.put("exitCode", process.exitValue());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Execution failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void getMemoryInfo(PluginCall call) {
        Runtime runtime = Runtime.getRuntime();
        long maxMemory = runtime.maxMemory();
        long totalMemory = runtime.totalMemory();
        long freeMemory = runtime.freeMemory();

        JSObject ret = new JSObject();
        ret.put("total", totalMemory);
        ret.put("free", freeMemory);
        ret.put("max", maxMemory);
        ret.put("used", totalMemory - freeMemory);
        call.resolve(ret);
    }
}
