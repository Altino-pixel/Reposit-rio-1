package com.venera.auxilio;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(VeneraSystemPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
