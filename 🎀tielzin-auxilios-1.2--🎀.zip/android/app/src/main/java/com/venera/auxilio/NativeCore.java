package com.venera.auxilio;

/**
 * Ponte para o motor nativo em C++
 * Compatível com AIDE e Android Studio
 */
public class NativeCore {

    static {
        System.loadLibrary("venera_native");
    }

    // Funções nativas que já criamos no native-lib.cpp
    public native float calculateStabilization(float raw_sens, float jitter_factor);
    public native float calculateMagnetism(float dist, float strength);
    public native String getCoreVersion();

    private static NativeCore instance;

    public static NativeCore getInstance() {
        if (instance == null) instance = new NativeCore();
        return instance;
    }
}
