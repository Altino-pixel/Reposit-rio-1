#include <jni.h>
#include <string>
#include <cmath>

extern "C" JNIEXPORT jfloat JNICALL
Java_com_venera_auxilio_VeneraSystemPlugin_calculateStabilization(
        JNIEnv* env,
        jobject /* this */,
        jfloat raw_sens,
        jfloat jitter_factor) {
    
    // Algoritmo de estabilização em C++ para máxima performance
    // Simula uma interpolação de alta frequência para suavizar o DPI
    float output = raw_sens * (1.0f - (jitter_factor * 0.05f));
    return (jfloat)std::round(output * 100.0f) / 100.0f;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_venera_auxilio_VeneraSystemPlugin_getCoreVersion(
        JNIEnv* env,
        jobject /* this */) {
    std::string version = "🎀tielzin-auxilios 🎀 C++ Engine v1.0.3-MAGNETIC";
    return env->NewStringUTF(version.c_str());
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_venera_auxilio_VeneraSystemPlugin_calculateMagnetism(
        JNIEnv* env,
        jobject /* this */,
        jfloat dist,
        jfloat strength) {
    // Cálculo vetorial de atração magnética em tempo real
    if (dist > 150.0f) return 0.0f;
    return (1.0f - (dist / 150.0f)) * (strength / 100.0f);
}
