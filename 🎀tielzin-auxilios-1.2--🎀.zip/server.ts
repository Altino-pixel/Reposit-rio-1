import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Python Analysis
  app.post("/api/analyze-sens", async (req, res) => {
    try {
      const config = req.body;
      const configStr = JSON.stringify(config).replace(/"/g, '\\"');
      
      // Chama o script Python
      const { stdout } = await execAsync(`echo "${configStr}" | python3 analyze_config.py`);
      const result = JSON.parse(stdout);
      
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to run Python analysis", details: error });
    }
  });

  // Health check pointing out the stack
  app.get("/api/stack", (req, res) => {
    res.json({
      frontend: "React + TypeScript + Tailwind",
      native_core: "C++ (NDK)",
      backend_analysis: "Python 3",
      status: "Operational"
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
