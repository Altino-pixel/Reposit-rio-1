import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.venera.auxilio',
  appName: 'VENERA X-SIGHT',
  webDir: 'dist',
  android: {
    path: '.'
  }
};

export default config;
