import React, { useState, useEffect } from 'react';
import { CrosshairConfig, DEFAULT_CONFIG } from './types';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Target, Zap, Eye, Menu, X, Play, Volume2, VolumeX, QrCode, Share2, Code2, Plus, Trash2, RotateCcw, Info, HelpCircle, Shield, ShieldCheck, ShieldAlert, Lock, Save as SaveIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppLauncher } from '@capacitor/app-launcher';
import { Toast } from '@capacitor/toast';
import { Device } from '@capacitor/device';
import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from './firebase';
import useSound from 'use-sound';



const VenusBackground = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none bg-[#020203]">
      {/* Stars */}
      {[...Array(50)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-0.5 h-0.5 bg-white rounded-full"
          initial={{ 
            opacity: Math.random(),
            x: `${Math.random() * 100}%`,
            y: `${Math.random() * 100}%`
          }}
          animate={{ 
            opacity: [0.2, 0.8, 0.2],
          }}
          transition={{
            duration: 2 + Math.random() * 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
      
      {/* Orbit Path */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-white/5 rounded-full" />
      
      {/* Venus Planet */}
      <motion.div
        className="absolute top-1/2 left-1/2 w-32 h-32 -translate-x-1/2 -translate-y-1/2"
        animate={{
          rotate: 360
        }}
        transition={{
          duration: 40,
          repeat: Infinity,
          ease: "linear"
        }}
      >
        <motion.div 
          className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full shadow-[0_0_30px_rgba(217,160,91,0.4)] overflow-hidden"
        >
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Venus-real_color.jpg/512px-Venus-real_color.jpg" 
            alt="Real Venus"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </motion.div>

      {/* Central Glow (Sun/Light source influence) */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-orange-500/5 rounded-full blur-[120px]" />
    </div>
  );
};

export default function App() {
  const [config, setConfig] = useState<CrosshairConfig>(DEFAULT_CONFIG);
  const [activeTab, setActiveTab] = useState('optimization');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [injectionLogs, setInjectionLogs] = useState<string[]>([]);
  const [isInjecting, setIsInjecting] = useState(false);
  const [targetPackage, setTargetPackage] = useState('');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionLogs, setConnectionLogs] = useState<string[]>([]);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [loginError, setLoginError] = useState('');
  const [deviceInfo, setDeviceInfo] = useState<any>(null);

  useEffect(() => {
    const initDevice = async () => {
      try {
        const info = await Device.getInfo();
        const id = await Device.getId();
        const deviceData = { ...info, ...id };
        setDeviceInfo(deviceData);
        
        // AUTO-BYPASS FOR USER'S OPPO F5 / CPH1723
        if (deviceData.model === 'CPH1723' || deviceData.model === 'Oppo F5') {
          console.log('Bypass detectado: Bem-vindo tielzin!');
          setIsLoggedIn(true);
        }
      } catch (e) {
        console.warn('Device info not available in browser');
      }
    };
    initDevice();
  }, []);

  const [userScripts, setUserScripts] = useState([
    { id: '1', name: 'Otimizador_FPS.js', content: '// Otimizador de FPS\n// Aumenta a prioridade do processo do jogo\nSystem.setPriority("HIGH");\nSystem.clearCache();\nconsole.log("FPS Otimizado!");', active: true },
    { id: '2', name: 'Macro_Puxada.js', content: '// Macro de Puxada Suave\n// Ajusta a sensibilidade vertical dinamicamente\nfunction onFire() {\n  Sensitivity.y += 0.5;\n  wait(100);\n  Sensitivity.y -= 0.5;\n}', active: false }
  ]);
  const [selectedScriptId, setSelectedScriptId] = useState('1');
  const [scriptLogs, setScriptLogs] = useState<string[]>([]);

  // Sound Effects
  const [playClick] = useSound('https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3', { volume: 0.5, soundEnabled });
  const [playSuccess] = useSound('https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3', { volume: 0.5, soundEnabled });
  const [playInject] = useSound('https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3', { volume: 0.3, soundEnabled });

  const [luaScripts, setLuaScripts] = useState({
    aimAssist: `-- Elite Aim Assist v4.2\nfunction on_aim_update(target_y, velocity)\n  if velocity > 50 then return -70 end\n  return target_y * 0.99\nend`,
    recoilControl: `-- Anti-Recoil Script\nfunction stabilize(y)\n  return y + math.random(-2, 2)\nend`,
    headMagnet: `-- Head Magnetism v2\nfunction lock_head(raw_y)\n  return math.max(-123, raw_y)\nend`
  });



  const updateConfig = (updates: Partial<CrosshairConfig>) => {
    if (soundEnabled) playClick();
    setConfig((prev) => {
      const newConfig = { ...prev, ...updates };
      
      // Real function simulation: Apply system-level changes
      if (updates.aggressiveFps !== undefined) {
        console.log(`[SYSTEM] Setting CPU Governor to: ${updates.aggressiveFps ? 'PERFORMANCE' : 'INTERACTIVE'}`);
      }
      if (updates.preciseTouch !== undefined) {
        console.log(`[SYSTEM] Touch Response Latency: ${updates.preciseTouch ? '1ms' : '16ms'}`);
      }
      if (updates.aimStabilizer !== undefined) {
        console.log(`[SYSTEM] Aim Assist Hook: ${updates.aimStabilizer ? 'ENABLED (0.25f)' : 'DISABLED'}`);
      }
      
      return newConfig;
    });
  };

  const launchGame = async (packageName: string) => {
    if (soundEnabled) playClick();
    setTargetPackage(packageName);
    setIsInjecting(true);
    setInjectionLogs([]);
    
    const logs = [
      "🔍 Localizando diretório do jogo...",
      "📂 Acessando /data/user/0/" + packageName,
      "🛡️ Solicitando permissões via Shizuku API...",
      "✅ Permissão concedida!",
      "📜 Car Carregando Engine Lua v5.4...",
      "⚙️ Compilando scripts .lua...",
      "💉 Injetando aim_assist.lua (Elite v4.2)...",
      "💉 Injetando anti_recoil.lua (Stabilizer)...",
      "💉 Injetando head_magnet.lua (Lock v2)...",
      "✅ Scripts Lua ativos na memória do jogo!",
      "💉 Otimizando Latência de Toque (1ms)...",
      "⚙️ Ajustando CPU Governor para PERFORMANCE...",
      "🚀 Limpando cache de renderização...",
      "🎀😈 O SEU APARELHO ESTÁ PRONTO 😈🎀"
    ];

    for (let i = 0; i < logs.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 600 + Math.random() * 800));
      if (soundEnabled) playInject();
      setInjectionLogs(prev => [...prev, logs[i]]);
    }

    if (soundEnabled) playSuccess();
    await new Promise(resolve => setTimeout(resolve, 1000));

    try {
      const { value } = await AppLauncher.canOpenUrl({ url: packageName });
      
      await Toast.show({
        text: '🎀😈o seu aparelho está pronto 😈🎀',
        duration: 'long',
        position: 'center'
      });

      if (value) {
        await AppLauncher.openUrl({ url: packageName });
      } else {
        alert('🎀😈o seu aparelho está pronto 😈🎀\n\n(Nota: No APK nativo, o jogo abrirá automaticamente)');
      }
    } catch (error) {
      console.error('Error launching game:', error);
      alert('🎀😈o seu aparelho está pronto 😈🎀');
    } finally {
      setIsInjecting(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (soundEnabled) playClick();
    setLoginError('');
    
    const key = loginForm.password.trim();
    const username = loginForm.username.trim().toLowerCase();
    
    // MASTER BYPASS: 'swiming7' or user 'tielzin' always works
    if (key === 'swiming7' || username === 'tielzin') {
      startConnectionSequence();
      if (soundEnabled) playSuccess();
      return;
    }
    
    // Pattern check: key-swiming[1-100]
    const keyMatch = key.match(/^key-swiming([1-9]|[1-9][0-9]|100)$/);
    
    if (!keyMatch) {
      setLoginError('Chave de acesso inválida.');
      return;
    }

    try {
      const docRef = doc(db, 'licenseKeys', key);
      const docSnap = await getDoc(docRef);
      
      const currentDeviceId = deviceInfo?.identifier || 'BROWSER_TEST';
      const currentModel = deviceInfo?.model || 'PC/Web';

      if (docSnap.exists()) {
        const data = docSnap.data();
        
        // Anti-sharing check
        if (data.deviceId && data.deviceId !== currentDeviceId) {
          setLoginError('Esta chave já está vinculada a outro dispositivo.');
          return;
        }

        // Update last used
        await updateDoc(docRef, {
          lastUsed: serverTimestamp()
        });
      } else {
        // First time using this key - Register device
        await setDoc(docRef, {
          key: key,
          deviceId: currentDeviceId,
          deviceModel: currentModel,
          createdAt: serverTimestamp(),
          lastUsed: serverTimestamp()
        });
      }

      startConnectionSequence();
      if (soundEnabled) playSuccess();
    } catch (error) {
      console.error('Erro no login:', error);
      setLoginError('Erro de conexão com o servidor de segurança.');
    }
  };

  const startConnectionSequence = async () => {
    setIsConnecting(true);
    setConnectionLogs([]);
    
    const logs = [
      "📡 Iniciando handshake com o Kernel Android...",
      "🔐 Autenticando token de acesso VENERA...",
      "🔗 Conectando ao Server Android (v14.0.2)...",
      "✅ Conexão estabelecida com sucesso!",
      "🚀 Carregando ambiente X-SIGHT PRO..."
    ];

    for (let i = 0; i < logs.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 500));
      setConnectionLogs(prev => [...prev, logs[i]]);
      if (soundEnabled) playInject();
    }

    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsConnecting(false);
    setIsLoggedIn(true);
  };

  if (isConnecting) {
    return (
      <div className="flex h-screen bg-zinc-950 text-zinc-100 font-sans items-center justify-center p-6 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/5 rounded-full blur-[150px] pointer-events-none" />
        
        <div className="flex flex-col items-center gap-8 z-10">
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 100 }}
            className="flex flex-col items-center gap-2"
          >
            <span className="text-5xl animate-bounce">🎀😈🎀</span>
            <h1 className="text-5xl font-black tracking-tighter text-blue-600">VENERA</h1>
          </motion.div>

          <div className="w-64 space-y-4">
            <div className="bg-black/40 border border-zinc-900 rounded-lg p-4 h-32 overflow-hidden font-mono text-[9px] text-zinc-500">
              <AnimatePresence mode="popLayout">
                {connectionLogs.map((log, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="mb-1 flex gap-2"
                  >
                    <span className="text-blue-900">{'>'}</span>
                    <span>{log}</span>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
            
            <div className="space-y-2">
              <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(connectionLogs.length / 5) * 100}%` }}
                  className="h-full bg-blue-600 shadow-[0_0_10px_rgba(37,99,235,0.5)]"
                />
              </div>
              <p className="text-[8px] text-center text-zinc-600 uppercase tracking-widest animate-pulse">
                Sincronizando com o sistema...
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!isLoggedIn) {
    return (
      <div className="flex h-screen bg-zinc-950 text-zinc-100 font-sans items-center justify-center p-6 relative overflow-hidden">
        <VenusBackground />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md z-10"
        >
          <Card className="bg-zinc-900/40 border-zinc-800/50 backdrop-blur-2xl shadow-2xl overflow-hidden relative">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-blue-600 to-transparent opacity-50" />
            
            <CardHeader className="text-center pb-8">
              <div className="flex flex-col items-center gap-4 mb-4">
                <h1 className="text-4xl font-black tracking-tighter text-blue-600 drop-shadow-[0_0_15px_rgba(37,99,235,0.5)]">VENERA</h1>
              </div>
              <CardTitle className="text-zinc-400 text-[10px] uppercase tracking-[0.3em] font-black">SISTEMA DE AUXÍLIO TÁTICO</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                  <Label className="text-[10px] text-zinc-500 uppercase font-bold ml-1">Usuário</Label>
                  <div className="relative">
                    <input
                      type="text"
                      value={loginForm.username}
                      onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                      className="w-full h-12 bg-black/50 border border-zinc-800 rounded-xl px-4 text-sm focus:outline-none focus:border-blue-600 transition-colors"
                      placeholder="Digite seu usuário..."
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] text-zinc-500 uppercase font-bold ml-1">Senha</Label>
                  <div className="relative">
                    <input
                      type="password"
                      value={loginForm.password}
                      onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                      className="w-full h-12 bg-black/50 border border-zinc-800 rounded-xl px-4 text-sm focus:outline-none focus:border-blue-600 transition-colors"
                      placeholder="••••••••"
                      required
                    />
                  </div>
                </div>

                <AnimatePresence>
                  {loginError && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="text-[10px] text-red-500 text-center font-bold uppercase tracking-wider"
                    >
                      {loginError}
                    </motion.div>
                  )}
                </AnimatePresence>

                <Button 
                  type="submit"
                  className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white font-black rounded-xl shadow-[0_0_20px_rgba(37,99,235,0.3)] transition-all active:scale-95"
                >
                  ENTRAR NO SISTEMA
                </Button>

                <div className="pt-2 text-center">
                  <a 
                    href="https://chat.whatsapp.com/I8O4txdJ1fECSvsxfkQkDJ" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-[10px] text-zinc-500 hover:text-blue-400 transition-colors uppercase font-bold tracking-widest flex items-center justify-center gap-2"
                  >
                    Não tem uma chave? <span className="text-blue-500 underline">COMPRAR ACESSO</span>
                  </a>
                </div>
              </form>
            </CardContent>
            <CardFooter className="justify-center border-t border-zinc-800/50 pt-6">
              <p className="text-[9px] text-zinc-600 uppercase tracking-widest">
                © 2026 VENERA-AUXILIOS ELITE
              </p>
            </CardFooter>
          </Card>
        </motion.div>
      </div>
    );
  }

  const getBackgroundClass = () => {
    switch (config.graphicsProfile) {
      case 'mine': return 'bg-black'; // Ultra performance
      case 'standard': return 'bg-zinc-950'; // Balanced
      case 'polished': return 'bg-[#050505]'; // Elite/Polished
      default: return 'bg-zinc-950';
    }
  };

  return (
    <div className={`flex h-screen ${getBackgroundClass()} text-zinc-100 font-sans overflow-hidden relative transition-colors duration-700`}>
      {/* Dynamic Background Effects */}
      {config.graphicsProfile === 'polished' && (
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(37,99,235,0.03),transparent)] pointer-events-none" />
      )}
      
      {/* Injection Overlay Panel */}
      <AnimatePresence>
        {isInjecting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 backdrop-blur-xl z-[100] flex items-center justify-center p-6"
          >
            <Card className="w-full max-w-lg bg-zinc-950 border-zinc-800 shadow-[0_0_50px_rgba(0,0,0,0.5)]">
              <CardHeader className="border-b border-zinc-900">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
                  <CardTitle className="text-sm font-black tracking-widest uppercase text-blue-500">
                    Terminal de Injeção de Elite
                  </CardTitle>
                </div>
                <CardDescription className="text-[10px] text-zinc-600 font-mono">
                  Target: {targetPackage}
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="bg-black/50 rounded-lg p-4 h-64 overflow-y-auto font-mono text-[10px] space-y-2 scrollbar-hide">
                  {injectionLogs.map((log, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={log.includes('🎀') ? 'text-blue-400 font-bold pt-2 border-t border-zinc-900 mt-2' : 'text-zinc-400'}
                    >
                      <span className="text-zinc-700 mr-2">[{new Date().toLocaleTimeString()}]</span>
                      {log}
                    </motion.div>
                  ))}
                  {injectionLogs.length < 10 && (
                    <div className="flex items-center gap-2 text-zinc-800">
                      <div className="w-1 h-3 bg-zinc-800 animate-pulse" />
                      <span>Processando...</span>
                    </div>
                  )}
                </div>
                <div className="mt-6 flex flex-col items-center gap-2">
                  <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(injectionLogs.length / 10) * 100}%` }}
                      className="h-full bg-blue-600 shadow-[0_0_15px_rgba(37,99,235,0.5)]"
                    />
                  </div>
                  <span className="text-[9px] text-zinc-600 uppercase tracking-tighter">
                    Injetando módulos de alta performance...
                  </span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 w-[280px] bg-zinc-900 border-r border-zinc-800 flex flex-col p-6 z-50 transition-transform duration-300 lg:relative lg:translate-x-0 shrink-0
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex items-center justify-between mb-12">
          <div className="flex flex-col items-center w-full gap-0 bg-zinc-950/50 p-4 rounded-2xl border border-zinc-800/50 shadow-inner">
            <span className="text-xl mb-1">🎀😈🎀</span>
            <h1 className="text-2xl font-black tracking-tighter text-blue-600 leading-none">VENERA</h1>
            <div className="w-12 h-1 bg-blue-600/30 rounded-full mt-2" />
          </div>
          <Button variant="ghost" size="icon" onClick={() => setIsSidebarOpen(false)} className="lg:hidden text-zinc-500 absolute top-4 right-4">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <nav className="flex flex-col gap-2">
          <NavItem
            active={activeTab === 'calibration'}
            onClick={() => { setActiveTab('calibration'); setIsSidebarOpen(false); }}
            icon={<Target className="w-4 h-4" />}
            label="Calibração de Puxada"
          />
          <NavItem
            active={activeTab === 'optimization'}
            onClick={() => { setActiveTab('optimization'); setIsSidebarOpen(false); }}
            icon={<Zap className="w-4 h-4" />}
            label="Otimização de Sistema"
          />
          <NavItem
            active={activeTab === 'scriptable'}
            onClick={() => { setActiveTab('scriptable'); setIsSidebarOpen(false); }}
            icon={<Code2 className="w-4 h-4" />}
            label="Scriptable"
          />
          <NavItem
            active={activeTab === 'security'}
            onClick={() => { setActiveTab('security'); setIsSidebarOpen(false); }}
            icon={<Shield className="w-4 h-4" />}
            label="Segurança (Anti-Detec)"
          />
          <NavItem
            active={activeTab === 'info'}
            onClick={() => { setActiveTab('info'); setIsSidebarOpen(false); }}
            icon={<Info className="w-4 h-4" />}
            label="Informações"
          />


        </nav>


      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="p-4 lg:p-8 border-b border-zinc-800 flex justify-between items-center shrink-0 bg-zinc-950/50 backdrop-blur-md">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => setIsSidebarOpen(true)} className="lg:hidden text-zinc-400">
              <Menu className="w-6 h-6" />
            </Button>
            <div>
              <h2 className="text-lg lg:text-2xl font-bold truncate max-w-[200px] md:max-w-none">Painel de Controle</h2>
              <p className="hidden md:block text-zinc-500 text-sm mt-1">Ajuste fino para assistência tática em tempo real</p>
            </div>
          </div>
          <div className="status-pill scale-75 md:scale-100">Ativo v2.4</div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="text-zinc-500 hover:text-blue-500 ml-2"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </Button>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-8">
          <div className="max-w-4xl mx-auto space-y-6">
            
            {/* Main Settings Area */}
            <div className="space-y-6">
              <AnimatePresence mode="wait">
                {activeTab === 'calibration' && (
                  <motion.div
                    key="calibration"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="grid grid-cols-1 gap-6"
                  >
                    <SensitivityCalibrator config={config} />
                  </motion.div>
                )}

                {activeTab === 'optimization' && (
                  <motion.div
                    key="optimization"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="grid grid-cols-1 md:grid-cols-2 gap-6"
                  >
                    <Card className="bg-zinc-900 border-zinc-800 text-zinc-100">
                      <CardHeader>
                        <CardTitle className="card-title">Assistência de Mira</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <OptimizationToggle
                          label="Estabilizador de Sensibilidade"
                          description="Suaviza o movimento para maior fluidez."
                          tooltip="Previne variações bruscas no DPI, garantindo que o movimento da mira seja linear e sem pulos."
                          checked={config.sensitivityStabilizer}
                          onChange={(v) => updateConfig({ sensitivityStabilizer: v })}
                        />
                        <OptimizationToggle
                          label="Estabilizador de Mira"
                          description="Auxílio de 25% na proximidade do alvo."
                          tooltip="Aumenta levemente a precisão quando o crosshair está próximo ao oponente, simulando um 'magnetismo' controlado."
                          checked={config.aimStabilizer}
                          onChange={(v) => updateConfig({ aimStabilizer: v })}
                        />
                        <OptimizationToggle
                          label="Rastreamento de Mira"
                          description="Sugere puxadas fluidas ao disparar."
                          tooltip="Ajusta algoritmos internos para facilitar o acompanhamento de alvos em movimento lateral constante."
                          checked={config.aimTracking}
                          onChange={(v) => updateConfig({ aimTracking: v })}
                        />
                      </CardContent>
                    </Card>

                    <Card className="bg-zinc-900 border-zinc-800 text-zinc-100">
                      <CardHeader>
                        <CardTitle className="card-title">Performance de Hardware</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <OptimizationToggle
                          label="Toque Preciso"
                          description="Melhora a resposta do botão de disparo."
                          tooltip="Reduz o tempo de resposta entre o clique físico e a ação no jogo, essencial para disparos rápidos (one-tap)."
                          checked={config.preciseTouch}
                          onChange={(v) => updateConfig({ preciseTouch: v })}
                        />
                        <OptimizationToggle
                          label="FPS Agressivo"
                          description="Força o desempenho máximo do motor."
                          tooltip="Otimiza a alocação de recursos da GPU e limpa processos em segundo plano para manter a taxa de quadros estável."
                          checked={config.aggressiveFps}
                          onChange={(v) => updateConfig({ aggressiveFps: v })}
                        />
                        <div className="pt-2">
                          <Label className="text-xs text-zinc-500 mb-3 block">PERFIL GRÁFICO</Label>
                          <div className="grid grid-cols-3 gap-2">
                            {(['mine', 'standard', 'polished'] as const).map((p) => (
                              <Button
                                key={p}
                                variant={config.graphicsProfile === p ? 'default' : 'outline'}
                                size="sm"
                                onClick={() => updateConfig({ graphicsProfile: p })}
                                className={`capitalize text-[10px] h-8 ${
                                  config.graphicsProfile === p 
                                    ? 'bg-blue-600 hover:bg-blue-700 text-white border-transparent' 
                                    : 'bg-transparent border-zinc-800 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100'
                                }`}
                              >
                                {p === 'mine' ? 'Mine' : p === 'standard' ? 'Padrão' : 'Elite'}
                              </Button>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-zinc-900 border-zinc-800 text-zinc-100">
                      <CardHeader>
                        <CardTitle className="card-title">Customização de Mira</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <ControlSlider
                          label="Tamanho da Mira"
                          value={config.size}
                          min={2}
                          max={50}
                          onChange={(v) => updateConfig({ size: v })}
                        />
                        <ControlSlider
                          label="Espessura"
                          value={config.thickness}
                          min={1}
                          max={10}
                          onChange={(v) => updateConfig({ thickness: v })}
                        />
                        <ControlSlider
                          label="Espaçamento (Gap)"
                          value={config.gap}
                          min={0}
                          max={20}
                          onChange={(v) => updateConfig({ gap: v })}
                        />
                        <ControlSlider
                          label="Opacidade"
                          value={Math.round(config.opacity * 100)}
                          min={0}
                          max={100}
                          unit="%"
                          onChange={(v) => updateConfig({ opacity: v / 100 })}
                        />
                      </CardContent>
                    </Card>

                    <Card className="bg-zinc-900 border-zinc-800 text-zinc-100 md:col-span-2">
                      <CardHeader className="pb-2">
                        <CardTitle className="card-title flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                          Modo APK Nativo (Capacitor)
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-[10px] text-zinc-500 leading-relaxed mb-4">
                          Este projeto foi convertido para a estrutura nativa Android. Ao compilar o APK, você terá acesso à permissão <b>SYSTEM_ALERT_WINDOW</b> e suporte ao <b>Shizuku API</b>, permitindo otimizações de sistema e overlay avançado.
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-lg space-y-1">
                            <h5 className="text-[10px] font-bold text-blue-400 uppercase mb-1">Status da Ponte</h5>
                            <p className="text-[9px] text-zinc-600 font-mono">Capacitor Android Bridge: INITIALIZED</p>
                            <p className="text-[9px] text-zinc-600 font-mono">Shizuku API: READY (v13.1.5)</p>
                            <p className="text-[9px] text-zinc-600 font-mono">Min SDK: 24 (Android 7.0+)</p>
                          </div>
                          <Button 
                            variant="outline" 
                            className="h-full border-zinc-800 hover:bg-zinc-800 text-[10px] text-zinc-400 py-3"
                            onClick={() => alert('No APK nativo, isso abrirá as configurações de "Sobrepor a outros aplicativos" do Android.')}
                          >
                            Solicitar Permissão de Overlay
                          </Button>
                        </div>

                        <div className="mt-6 pt-6 border-t border-zinc-800">
                          <h4 className="text-[10px] font-bold text-zinc-500 uppercase mb-4 tracking-widest">Acesso Rápido ao Jogo</h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Button 
                              onClick={() => launchGame('com.dts.freefireth')}
                              className="bg-orange-600 hover:bg-orange-700 text-white font-bold h-12 rounded-xl shadow-[0_0_20px_rgba(234,88,12,0.3)]"
                            >
                              <Play className="w-4 h-4 mr-2 fill-current" />
                              ABRIR FREE FIRE
                            </Button>
                            <Button 
                              onClick={() => launchGame('com.dts.freefiremax')}
                              className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 h-12 rounded-xl"
                            >
                              <Play className="w-4 h-4 mr-2" />
                              ABRIR FF MAX
                            </Button>
                          </div>
                          <p className="text-[9px] text-zinc-600 mt-3 text-center italic">
                            * Ao abrir, o sistema injetará automaticamente as otimizações configuradas.
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}

                {activeTab === 'scriptable' && (
                  <motion.div
                    key="scriptable"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full"
                  >
                    {/* Script List */}
                    <Card className="bg-zinc-900 border-zinc-800 text-zinc-100 lg:col-span-1 flex flex-col overflow-hidden">
                      <CardHeader className="p-4 border-b border-zinc-800 flex flex-row items-center justify-between shrink-0">
                        <CardTitle className="text-sm font-bold uppercase tracking-widest text-zinc-500">Scripts</CardTitle>
                        <div className="flex items-center gap-1">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-blue-500 hover:bg-blue-500/10"
                            onClick={() => {
                              if (soundEnabled) playClick();
                              const allActive = userScripts.every(s => s.active);
                              setUserScripts(userScripts.map(s => ({ ...s, active: !allActive })));
                              setScriptLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Todos os scripts ${!allActive ? 'ativados' : 'desativados'}.`]);
                            }}
                            title="Alternar Todos"
                          >
                            <Zap className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-blue-500 hover:bg-blue-500/10"
                            onClick={() => {
                              const newId = Date.now().toString();
                              setUserScripts([...userScripts, { id: newId, name: 'NovoScript.js', content: '// Novo Script\n', active: false }]);
                              setSelectedScriptId(newId);
                            }}
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent className="p-2 flex-1 overflow-y-auto space-y-1 scrollbar-hide">
                        {userScripts.map(script => (
                          <div
                            key={script.id}
                            onClick={() => setSelectedScriptId(script.id)}
                            className={`group flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all ${selectedScriptId === script.id ? 'bg-blue-600/10 border border-blue-600/30' : 'hover:bg-zinc-800/50 border border-transparent'}`}
                          >
                            <div className="flex items-center gap-3">
                              <div className={`w-2 h-2 rounded-full ${script.active ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]' : 'bg-zinc-700'}`} />
                              <span className={`text-xs font-medium ${selectedScriptId === script.id ? 'text-blue-400' : 'text-zinc-400'}`}>{script.name}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className={`h-7 w-7 transition-all ${script.active ? 'text-green-500' : 'text-zinc-600 hover:text-blue-500'}`}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (soundEnabled) playClick();
                                  setUserScripts(userScripts.map(s => s.id === script.id ? { ...s, active: !s.active } : s));
                                  if (!script.active) {
                                    setScriptLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Executando ${script.name}...`]);
                                    if (soundEnabled) playSuccess();
                                  } else {
                                    setScriptLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Script ${script.name} interrompido.`]);
                                  }
                                }}
                              >
                                {script.active ? <RotateCcw className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-7 w-7 opacity-0 group-hover:opacity-100 text-zinc-600 hover:text-red-500 transition-opacity"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setUserScripts(userScripts.filter(s => s.id !== script.id));
                                  if (selectedScriptId === script.id) setSelectedScriptId(userScripts[0]?.id || '');
                                }}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </CardContent>
                    </Card>

                    {/* Editor & Console */}
                    <div className="lg:col-span-2 flex flex-col gap-6 h-full">
                      <Card className="bg-zinc-900 border-zinc-800 text-zinc-100 flex-1 flex flex-col overflow-hidden min-h-[400px]">
                        <CardHeader className="p-4 border-b border-zinc-800 flex flex-row items-center justify-between shrink-0">
                          <div className="flex flex-col">
                            <input 
                              value={userScripts.find(s => s.id === selectedScriptId)?.name || ''}
                              onChange={(e) => {
                                setUserScripts(userScripts.map(s => s.id === selectedScriptId ? { ...s, name: e.target.value } : s));
                              }}
                              className="bg-transparent border-none text-sm font-bold text-zinc-100 focus:outline-none focus:ring-0 p-0 w-full"
                            />
                            <span className="text-[9px] text-zinc-500 uppercase tracking-widest font-mono">JavaScript Engine v1.0</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 text-[10px] font-bold text-zinc-500 hover:text-zinc-100"
                              onClick={() => {
                                if (soundEnabled) playClick();
                                setScriptLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Script salvo com sucesso.`]);
                              }}
                            >
                              <SaveIcon className="w-3 h-3 mr-2" />
                              SALVAR
                            </Button>
                            <Button 
                              size="sm" 
                              className={`h-8 text-[10px] font-bold px-4 rounded-lg transition-all ${userScripts.find(s => s.id === selectedScriptId)?.active ? 'bg-red-600/20 text-red-500 border border-red-500/30 hover:bg-red-600/30' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
                              onClick={() => {
                                if (soundEnabled) playClick();
                                const script = userScripts.find(s => s.id === selectedScriptId);
                                if (!script) return;
                                
                                setUserScripts(userScripts.map(s => s.id === selectedScriptId ? { ...s, active: !s.active } : s));
                                
                                if (!script.active) {
                                  setScriptLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Executando ${script.name}...`, `[${new Date().toLocaleTimeString()}] Script injetado com sucesso.`]);
                                  if (soundEnabled) playSuccess();
                                } else {
                                  setScriptLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Script ${script.name} interrompido.`]);
                                }
                              }}
                            >
                              {userScripts.find(s => s.id === selectedScriptId)?.active ? 'PARAR' : 'EXECUTAR'}
                            </Button>
                          </div>
                        </CardHeader>
                        <CardContent className="p-0 flex-1 relative">
                          <textarea
                            value={userScripts.find(s => s.id === selectedScriptId)?.content || ''}
                            onChange={(e) => {
                              setUserScripts(userScripts.map(s => s.id === selectedScriptId ? { ...s, content: e.target.value } : s));
                            }}
                            className="w-full h-full bg-zinc-950 p-6 font-mono text-xs text-blue-400/80 resize-none focus:outline-none scrollbar-hide leading-relaxed"
                            spellCheck={false}
                            placeholder="// Digite seu script aqui..."
                          />
                        </CardContent>
                      </Card>

                      {/* Script Console */}
                      <Card className="bg-zinc-900 border-zinc-800 text-zinc-100 h-40 flex flex-col overflow-hidden">
                        <CardHeader className="p-3 border-b border-zinc-800 shrink-0">
                          <CardTitle className="text-[9px] font-bold uppercase tracking-widest text-zinc-500">Console de Saída</CardTitle>
                        </CardHeader>
                        <CardContent className="p-4 flex-1 overflow-y-auto font-mono text-[10px] space-y-1 bg-black/30 scrollbar-hide">
                          {scriptLogs.length === 0 && <div className="text-zinc-700 italic">Nenhuma saída registrada.</div>}
                          {scriptLogs.map((log, i) => (
                            <div key={i} className={log.includes('sucesso') ? 'text-green-500/70' : log.includes('interrompido') ? 'text-red-500/70' : 'text-zinc-500'}>
                              {log}
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'security' && (
                  <motion.div
                    key="security"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-6"
                  >
                    <Card className="bg-zinc-900 border-zinc-800 text-zinc-100">
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <div className="space-y-1">
                          <CardTitle className="card-title flex items-center gap-2">
                            <ShieldCheck className="w-5 h-5 text-green-500" />
                            Módulo Anti-Detecção v1.0
                          </CardTitle>
                          <CardDescription className="text-zinc-500 text-xs">
                            Proteção de conta e ofuscação de assinatura digital.
                          </CardDescription>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-[10px] font-bold border ${config.antiDetection ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20'}`}>
                          {config.antiDetection ? 'SISTEMA PROTEGIDO' : 'PROTEÇÃO DESATIVADA'}
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-6 pt-4">
                        <OptimizationToggle
                          label="Anti-Detection Core"
                          description="Habilita o núcleo de proteção contra assinaturas conhecidas."
                          tooltip="Analisa e amoca o identificador do processo VENERA para evitar que o anti-cheat o localize na memória via strings."
                          checked={config.antiDetection}
                          onChange={(v) => updateConfig({ antiDetection: v })}
                        />
                        <OptimizationToggle
                          label="Stealth Overlay (Pixel Shifting)"
                          description="Flutuação invisível da posição da mira."
                          tooltip="Move a mira em 0.1 pixel aleatoriamente. Isso impede que sistemas automáticos detectem um elemento estático perfeito no meio da tela."
                          checked={config.stealthOverlay}
                          onChange={(v) => updateConfig({ stealthOverlay: v })}
                        />
                        <OptimizationToggle
                          label="Engine Jitter"
                          description="Randomiza tempos de resposta dos scripts."
                          tooltip="Adiciona pequenos atrasos milimétricos (1-5ms) aos cálculos de sensibilidade para simular a imperfeição humana e evitar detecção de padrões."
                          checked={config.jitterEngine}
                          onChange={(v) => updateConfig({ jitterEngine: v })}
                        />
                        <OptimizationToggle
                          label="Ofuscação de Bytecode"
                          description="Criptografa a memória de execução dos scripts."
                          tooltip="Exige Shizuku ou Apenas Root. Envolve os scripts injetados em uma camada de proteção que os torna ilegíveis para scanners de memória."
                          checked={config.byteObfuscation}
                          onChange={(v) => updateConfig({ byteObfuscation: v })}
                        />
                        <OptimizationToggle
                          label="Modo Invisível (Anti-Gravação)"
                          description="Impede que aplicativos de gravação de tela detectem o overlay."
                          tooltip="Ativa um modo que torna o overlay do aplicativo invisível para softwares de gravação de tela e analisadores de captura de imagem, protegendo sua sessão."
                          checked={config.antiRecording}
                          onChange={(v) => updateConfig({ antiRecording: v })}
                        />

                        <div className="p-4 bg-blue-600/5 border border-blue-600/20 rounded-xl space-y-2 mt-4">
                          <div className="flex items-center gap-2 text-blue-400 font-bold text-xs uppercase tracking-widest">
                            <Lock className="w-3.5 h-3.5" />
                            Status de Segurança Operacional
                          </div>
                          <ul className="text-[10px] text-zinc-500 space-y-1 font-mono">
                            <li>{'>'} Kernel Signature: HIDDEN</li>
                            <li>{'>'} Memory Leak Protection: ACTIVE</li>
                            <li>{'>'} Anti-Dump Protection: ENABLED</li>
                            <li>{'>'} Shizuku Bridge: STEALTH MODE</li>
                          </ul>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-red-600/5 border-red-900/20 text-red-200">
                      <CardContent className="p-4 flex items-start gap-4">
                        <ShieldAlert className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                        <div className="space-y-1">
                          <p className="text-xs font-bold uppercase tracking-tight">Aviso de Segurança</p>
                          <p className="text-[10px] text-zinc-500 leading-relaxed">
                            Nenhum sistema é 100% infalível. Embora o Módulo Anti-Detecção reduza drasticamente o risco de banimentos automáticos, o uso de scripts manuais absurdos (como teleport ou headshot 100%) pode aumentar o risco de denúncias manuais de outros jogadores. Use com sabedoria.
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}

                {activeTab === 'info' && (
                  <motion.div
                    key="info"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-6"
                  >
                    <Card className="bg-zinc-900 border-zinc-800 text-zinc-100">
                      <CardHeader>
                        <CardTitle className="card-title">Guia de Funções</CardTitle>
                        <CardDescription className="text-zinc-500 text-xs">Entenda como cada componente otimiza sua experiência.</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <div className="space-y-4">
                          <div className="p-4 bg-zinc-950/50 border border-zinc-800 rounded-xl">
                            <h4 className="text-blue-400 font-bold text-sm mb-2 uppercase tracking-wider">Calibração de Puxada</h4>
                            <p className="text-zinc-400 text-xs leading-relaxed">
                              Analisa o seu padrão de movimento vertical ao disparar. Ao realizar 10 puxadas de teste, o sistema calcula a sensibilidade ideal (Geral, Red Dot, 2x, 4x) para que sua mira acompanhe o alvo com precisão máxima.
                            </p>
                          </div>

                          <div className="p-4 bg-zinc-950/50 border border-zinc-800 rounded-xl">
                            <h4 className="text-blue-400 font-bold text-sm mb-2 uppercase tracking-wider">Otimização de Sistema</h4>
                            <ul className="space-y-3">
                              <li className="text-xs text-zinc-400">
                                <strong className="text-zinc-200 block mb-1">Assistência de Mira:</strong>
                                Inclui estabilizadores que suavizam tremores e ajudam a manter a mira próxima ao alvo durante o rastreamento.
                              </li>
                              <li className="text-xs text-zinc-400">
                                <strong className="text-zinc-200 block mb-1">Performance de Hardware:</strong>
                                Ajusta o tempo de resposta do toque (Touch Latency) e otimiza o uso da CPU para garantir FPS estável em situações de combate intenso.
                              </li>
                              <li className="text-xs text-zinc-400">
                                <strong className="text-zinc-200 block mb-1">Customização de Mira:</strong>
                                Permite ajustar visualmente o crosshair (tamanho, espessura, gap) para melhor visibilidade em diferentes mapas.
                              </li>
                            </ul>
                          </div>

                          <div className="p-4 bg-zinc-950/50 border border-zinc-800 rounded-xl">
                            <h4 className="text-blue-400 font-bold text-sm mb-2 uppercase tracking-wider">Scriptable</h4>
                            <p className="text-zinc-400 text-xs leading-relaxed">
                              Um motor de automação avançado onde você pode carregar scripts JavaScript personalizados para funções específicas como macros de movimento, otimizadores de memória e ajustes finos de sensibilidade via código.
                            </p>
                          </div>

                          <div className="p-4 bg-zinc-950/50 border border-zinc-800 rounded-xl">
                            <h4 className="text-blue-400 font-bold text-sm mb-2 uppercase tracking-wider">Segurança (Anti-Detecção)</h4>
                            <p className="text-zinc-400 text-xs leading-relaxed">
                              Um conjunto de ferramentas defensivas que utilizam ofuscação de memória, jitter de execução e deslocamento imperceptível de mira. Inclui o <strong>Modo Invisível</strong>, que protege contra gravadores de tela e analisadores de imagem.
                            </p>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex flex-col items-center border-t border-zinc-800 pt-8 pb-8">
                        <div className="text-center space-y-2">
                          <p className="text-blue-500 font-black text-sm tracking-widest uppercase">
                            Criado por tielzin©
                          </p>
                          <p className="text-zinc-600 text-[10px] font-medium uppercase tracking-[0.2em]">
                            Todos os direitos reservados colopyright2026®
                          </p>
                        </div>
                      </CardFooter>
                    </Card>
                  </motion.div>
                )}


              </AnimatePresence>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function SensitivityCalibrator({ config }: { config: CrosshairConfig }) {
  const [isDragging, setIsDragging] = useState(false);
  const [startY, setStartY] = useState(0);
  const [currentY, setCurrentY] = useState(0);
  const [pulls, setPulls] = useState<number[]>([]);
  const [perfectPullsCount, setPerfectPullsCount] = useState(0);
  const [sensitivities, setSensitivities] = useState({
    geral: 0,
    redDot: 0,
    mira2x: 0,
    mira4x: 0,
  });

  const handleStart = (e: React.PointerEvent) => {
    if (pulls.length >= 10) return;
    setIsDragging(true);
    setStartY(e.clientY);
    setCurrentY(e.clientY);
  };

  const handleMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setCurrentY(e.clientY);
  };

  const handleEnd = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setIsDragging(false);
    
    const deltaY = startY - e.clientY;
    const speed = Math.max(0, deltaY);
    
    // Check if this specific pull was perfect
    // Using the same logic as the real-time simulation
    const dragOffsetTemp = Math.max(-50, (speed) * 0.45);
    const pullVelocityTemp = Math.abs(dragOffsetTemp);
    const isPerfect = pullVelocityTemp >= 15 && pullVelocityTemp < 40;
    
    if (isPerfect) setPerfectPullsCount(prev => prev + 1);

    const newPulls = [...pulls, speed];
    setPulls(newPulls);
    
    if (newPulls.length === 10) {
      const avgSpeed = newPulls.reduce((a, b) => a + b, 0) / 10;
      const base = Math.min(200, Math.max(0, Math.round((avgSpeed / 300) * 200)));
      
      setSensitivities({
        geral: base,
        redDot: Math.min(200, Math.round(base * 0.9)),
        mira2x: Math.min(200, Math.round(base * 0.85)),
        mira4x: Math.min(200, Math.round(base * 0.8)),
      });
    }
    
    setCurrentY(startY);
  };

  const resetCalibration = () => {
    setPulls([]);
    setPerfectPullsCount(0);
    setSensitivities({ geral: 0, redDot: 0, mira2x: 0, mira4x: 0 });
  };

  // "Heavier" drag logic: apply a stronger resistance factor (0.35) for even more weight
  // Limit the movement even more to prevent lag/stuttering (-50 instead of -80)
  const dragOffset = isDragging ? Math.max(-50, (currentY - startY) * 0.45) : 0; // Increased factor for faster response
  
  // Velocity calculation for the current frame
  const pullVelocity = Math.abs(dragOffset);
  
  // Aim Assist Logic (Elite Calibration)
  // 1. Calculate raw aim position (starts at feet)
  const rawAimY = -10 + (dragOffset * 5.2); // Increased multiplier for maximum responsiveness
  
  // 2. Multi-stage Magnetism with Velocity Penalty
  const chestY = -70;
  const neckY = -95;
  const headY = -118;
  
  // Perfect pull range (ideal speed for "capa")
  const isTooSlow = pullVelocity < 15;
  const isPerfectSpeed = pullVelocity >= 15 && pullVelocity < 40; // Widened range for "meio termo"
  const isTooFast = pullVelocity >= 40;
  
  let stickiness = 0;
  
  if (isTooSlow) {
    // Very slow: No magnetism, aim stays at raw position (simulates "passing" or "not reaching")
    stickiness = 0;
  } else if (isTooFast) {
    // Penalty: High velocity locks to the chest, but with slightly less intensity (0.92) to avoid "too stuck"
    stickiness = (chestY - rawAimY) * 0.92;
  } else if (isPerfectSpeed) {
    // Perfect: Guide directly to head with balanced resistance (0.35) to avoid "too stuck" on head
    stickiness = (headY - rawAimY) * 0.35;
  } else {
    // Standard multi-stage logic (Balanced strengths)
    if (rawAimY > -85) {
      stickiness = (chestY - rawAimY) * 0.85; // Reduced from 0.95
    } else if (rawAimY > -105) {
      stickiness = (neckY - rawAimY) * 0.8; // Reduced from 0.9
    } else {
      stickiness = (headY - rawAimY) * 0.7; // Reduced from 0.8
    }
  }
  
  // 3. Recoil & Tremor
  const isAtHead = (rawAimY + stickiness) < -110;
  const headTremor = (isDragging && isAtHead) ? (Math.random() - 0.5) * 12 : 0;
  const chestPull = (isDragging && isAtHead) ? 8 * Math.random() : 0;

  // 4. Final Position with Head Clamp (Não passa da cabeça)
  let finalCrosshairY = rawAimY + stickiness + headTremor + chestPull;
  finalCrosshairY = Math.max(headY - 5, finalCrosshairY); // Clamp at head level

  return (
    <Card className="bg-zinc-900 border-zinc-800 text-zinc-100">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="card-title">Calibrador de Puxada (Free Fire)</CardTitle>
            <CardDescription className="text-zinc-500 text-xs">
              Puxe com precisão. Velocidade excessiva trava no peito.
            </CardDescription>
          </div>
          {pulls.length > 0 && (
            <Button variant="ghost" size="sm" onClick={resetCalibration} className="text-[10px] text-zinc-500 hover:text-white">
              Reiniciar
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-8">
        <div className="flex flex-col md:flex-row gap-8 items-center justify-center">
          {/* Free Fire Style Simulation Area */}
          <div 
            className={`relative w-64 h-96 rounded-2xl border border-zinc-800 flex items-end justify-center pb-12 overflow-hidden cursor-crosshair touch-none transition-colors duration-500 ${config.graphicsProfile === 'mine' ? 'bg-zinc-950' : 'bg-zinc-900'}`}
            onPointerMove={handleMove}
            onPointerUp={handleEnd}
            onPointerLeave={handleEnd}
          >
            {/* Background Scenery Simulation */}
            {config.graphicsProfile !== 'mine' && (
              <div className={`absolute inset-0 opacity-20 bg-cover ${config.graphicsProfile === 'polished' ? "bg-[url('https://picsum.photos/seed/ff_elite/600/800')]" : "bg-[url('https://picsum.photos/seed/ff_field/600/800?blur=5')]"}`} />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
            
            {/* Perfect Pull Indicators (Invisible limits that appear) */}
            <AnimatePresence>
              {isDragging && isPerfectSpeed && (
                <>
                  <motion.div 
                    initial={{ opacity: 0 }} animate={{ opacity: 0.4 }} exit={{ opacity: 0 }}
                    className="absolute top-[22%] left-0 right-0 h-[1px] bg-blue-500/50 border-t border-dashed border-blue-400/30 z-10"
                  />
                  <motion.div 
                    initial={{ opacity: 0 }} animate={{ opacity: 0.4 }} exit={{ opacity: 0 }}
                    className="absolute top-[32%] left-0 right-0 h-[1px] bg-blue-500/50 border-t border-dashed border-blue-400/30 z-10"
                  />
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
                    className="absolute top-1/4 left-1/2 -translate-x-1/2 text-[8px] font-bold text-blue-400 uppercase tracking-tighter z-20"
                  >
                    Zona de Capa Perfeita
                  </motion.div>
                </>
              )}
            </AnimatePresence>

            {/* Muzzle Flash Simulation */}
            {isDragging && (
              <motion.div 
                animate={{ opacity: [0, 0.8, 0], scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 0.1 }}
                className="absolute bottom-24 w-12 h-12 bg-yellow-400/20 rounded-full blur-xl z-10"
              />
            )}

            {/* Opponent Dummy */}
            <div className="absolute top-20 flex flex-col items-center">
              {/* Head */}
              <div className="w-6 h-7 bg-zinc-800 rounded-full border border-zinc-700 relative">
                <div className={`absolute inset-0 rounded-full transition-colors ${finalCrosshairY < -110 ? 'bg-red-500/40' : 'bg-red-500/10'}`} />
              </div>
              {/* Body */}
              <div className="w-12 h-16 bg-zinc-800 rounded-t-xl border-x border-t border-zinc-700 mt-1" />
              
              {/* Hit Indicator (Simulated) */}
              {isDragging && finalCrosshairY < -110 && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1.2 }}
                  className="absolute -top-4 text-[10px] font-black text-red-500 drop-shadow-[0_0_5px_rgba(239,68,68,0.8)]"
                >
                  {isPerfectSpeed ? 'CAPA PERFEITO!' : 'HEADSHOT!'}
                </motion.div>
              )}
            </div>

            {/* White Crosshair (Mira Branca) */}
            <motion.div 
              animate={{ y: finalCrosshairY }}
              className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-30 pointer-events-none ${config.antiRecording ? 'opacity-40 brightness-150 contrast-150 mix-blend-screen' : ''}`}
              style={config.antiRecording ? { filter: 'blur(0.2px) drop-shadow(0 0 1px rgba(255,255,255,0.5))' } : {}}
            >
              <div className="relative flex items-center justify-center">
                {/* Crosshair Lines */}
                <div className="absolute w-4 h-[1.5px] bg-white/80 -left-5" />
                <div className="absolute w-4 h-[1.5px] bg-white/80 -right-5" />
                <div className="absolute w-[1.5px] h-4 bg-white/80 -top-5" />
                <div className="absolute w-[1.5px] h-4 bg-white/80 -bottom-5" />
                {/* Center Dot */}
                <div className={`w-1 h-1 rounded-full transition-colors duration-150 ${finalCrosshairY < -110 ? 'bg-red-500 shadow-[0_0_8px_red]' : 'bg-white'}`} />
                
                {/* Stealth Indicator */}
                {config.antiRecording && (
                  <div className="absolute -bottom-8 whitespace-nowrap text-[6px] text-zinc-600 font-mono uppercase tracking-widest opacity-20">
                    Stealth Active
                  </div>
                )}
              </div>
            </motion.div>
            
            {/* Progress Indicator */}
            <div className="absolute top-4 left-0 right-0 flex justify-center gap-1 px-4 z-40">
              {[...Array(10)].map((_, i) => (
                <div 
                  key={i} 
                  className={`h-1 flex-1 rounded-full transition-colors ${i < pulls.length ? 'bg-orange-500' : 'bg-zinc-800'}`}
                />
              ))}
            </div>

            <div className="absolute top-8 text-[10px] font-bold text-zinc-400 uppercase z-40">
              Puxadas: {pulls.length} / 10
            </div>
            
            <motion.button
              onPointerDown={handleStart}
              animate={{ y: dragOffset }}
              transition={isDragging ? { type: 'just' } : { type: 'spring', stiffness: 300, damping: 30 }}
              className="relative w-24 h-24 rounded-full bg-gradient-to-b from-orange-400 to-orange-600 shadow-[0_0_30px_rgba(249,115,22,0.4)] flex items-center justify-center border-4 border-orange-300/30 group z-20"
            >
              <div className="absolute inset-0 rounded-full border-2 border-white/20 animate-ping opacity-20" />
              <div className="w-16 h-16 rounded-full border-2 border-white/40 flex items-center justify-center">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <div className="w-4 h-4 bg-white rounded-full shadow-[0_0_10px_white]" />
                </div>
              </div>
              
              {/* Bullet Icon Simulation */}
              <div className="absolute -right-1 top-1/2 -translate-y-1/2 w-4 h-1 bg-white/60 rounded-full rotate-45" />
              <div className="absolute -right-1 bottom-1/2 translate-y-1/2 w-4 h-1 bg-white/60 rounded-full -rotate-45" />
            </motion.button>

            <div className="absolute bottom-4 text-[10px] text-zinc-600 font-mono uppercase tracking-widest z-40">
              {pulls.length === 10 ? 'Calibração Concluída' : isDragging ? 'Puxando...' : 'Arraste para cima'}
            </div>
          </div>

          {/* Results Area */}
          <div className="flex-1 w-full max-w-sm space-y-4">
            <div className="p-4 bg-blue-600/10 border border-blue-500/20 rounded-xl mb-6">
              <h4 className="text-[10px] font-bold text-blue-400 uppercase tracking-wider mb-2">Analisador de Precisão</h4>
              <div className="flex items-center justify-between">
                <span className="text-xs text-zinc-400">Puxadas Perfeitas:</span>
                <span className="text-lg font-black text-blue-500">{perfectPullsCount} <span className="text-[10px] text-zinc-600">/ 10</span></span>
              </div>
              <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden mt-3">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${(perfectPullsCount / 10) * 100}%` }}
                  className="h-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]"
                />
              </div>
            </div>

            <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-4">Sensibilidade Sugerida</h4>
            <div className="grid grid-cols-2 gap-4">
              <SensitivityResult label="Geral" value={sensitivities.geral} />
              <SensitivityResult label="Ponto Vermelho" value={sensitivities.redDot} />
              <SensitivityResult label="Mira 2x" value={sensitivities.mira2x} />
              <SensitivityResult label="Mira 4x" value={sensitivities.mira4x} />
            </div>
            
            <div className="mt-6 p-4 bg-zinc-950 border border-zinc-800 rounded-lg">
              <p className="text-[10px] text-zinc-500 leading-relaxed italic">
                * Estes valores são baseados na velocidade e distância da sua puxada simulada. Teste no jogo e ajuste conforme necessário.
              </p>
              <p className="text-[10px] text-blue-500 font-bold mt-2 text-center uppercase tracking-widest">
                Puxada Perfeita, Sensibilidade Perfeita
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function SensitivityResult({ label, value }: { label: string, value: number }) {
  return (
    <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1">
      <span className="text-[10px] text-zinc-500 uppercase font-bold">{label}</span>
      <div className="flex items-baseline gap-1">
        <span className="text-2xl font-black text-blue-500">{value}</span>
        <span className="text-[10px] text-zinc-600">/ 200</span>
      </div>
      <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden mt-2">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${(value / 200) * 100}%` }}
          className="h-full bg-blue-600"
        />
      </div>
    </div>
  );
}

function NavItem({ active, onClick, icon, label }: { active: boolean, onClick?: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm transition-all text-left ${
        active 
          ? 'bg-zinc-800 text-white border border-zinc-700 shadow-sm' 
          : 'text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200'
      }`}
    >
      <span className={active ? 'text-blue-500' : ''}>{icon}</span>
      {label}
    </button>
  );
}

function ControlSlider({ label, value, min, max, unit = "px", onChange }: { label: string, value: number, min: number, max: number, unit?: string, onChange: (v: number) => void }) {
  return (
    <div className="space-y-3">
      <div className="flex justify-between text-[13px] text-zinc-300">
        <Label>{label}</Label>
        <span className="font-mono text-blue-500">{value}{unit}</span>
      </div>
      <Slider
        value={[value]}
        min={min}
        max={max}
        step={1}
        onValueChange={(v) => {
          const val = Array.isArray(v) ? v[0] : v;
          onChange(val);
        }}
      />
    </div>
  );
}

function OptimizationToggle({ label, description, tooltip, checked, onChange }: { label: string, description: string, tooltip: string, checked: boolean, onChange: (v: boolean) => void }) {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div className="flex items-center justify-between gap-4 py-1 relative">
      <div className="space-y-0.5 relative">
        <div className="flex items-center gap-1.5">
          <Label className="text-[13px] font-medium text-zinc-200">{label}</Label>
          <div 
            onMouseEnter={() => setShowTooltip(true)}
            onMouseLeave={() => setShowTooltip(false)}
            className="text-zinc-600 hover:text-blue-500 cursor-help transition-colors"
          >
            <HelpCircle className="w-3 h-3" />
          </div>
          
          <AnimatePresence>
            {showTooltip && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 5 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 5 }}
                className="absolute left-0 bottom-full mb-2 w-48 p-2 bg-zinc-800 border border-zinc-700 rounded-lg shadow-xl z-50 pointer-events-none"
              >
                <p className="text-[9px] text-zinc-300 leading-snug">{tooltip}</p>
                <div className="absolute left-4 -bottom-1 w-2 h-2 bg-zinc-800 border-r border-b border-zinc-700 rotate-45" />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <p className="text-[10px] text-zinc-500 leading-tight">{description}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
