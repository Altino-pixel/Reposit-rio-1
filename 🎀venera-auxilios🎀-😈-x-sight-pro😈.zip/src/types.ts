export type CrosshairShape = 'cross' | 'circle' | 'dot' | 'square' | 't-shape';
export type GraphicsProfile = 'mine' | 'standard' | 'polished';

export interface CrosshairConfig {
  shape: CrosshairShape;
  size: number;
  thickness: number;
  gap: number;
  color: string;
  opacity: number;
  outline: boolean;
  outlineColor: string;
  outlineThickness: number;
  dot: boolean;
  dotSize: number;
  dotColor: string;
  // New Optimization Features
  sensitivityStabilizer: boolean;
  aimStabilizer: boolean;
  preciseTouch: boolean;
  aimTracking: boolean;
  aggressiveFps: boolean;
  graphicsProfile: GraphicsProfile;
  // Opponent Monitoring (Simulated)
  opponentMonitoring: boolean;
  radarEnabled: boolean;
  espEnabled: boolean;
  // Security & Anti-Detection
  antiDetection: boolean;
  stealthOverlay: boolean;
  byteObfuscation: boolean;
  jitterEngine: boolean;
  antiRecording: boolean;
}

export const DEFAULT_CONFIG: CrosshairConfig = {
  shape: 'cross',
  size: 10,
  thickness: 2,
  gap: 4,
  color: '#3b82f6',
  opacity: 1,
  outline: true,
  outlineColor: '#000000',
  outlineThickness: 1,
  dot: false,
  dotSize: 2,
  dotColor: '#3b82f6',
  // Default values for new features
  sensitivityStabilizer: false,
  aimStabilizer: false,
  preciseTouch: false,
  aimTracking: false,
  aggressiveFps: false,
  graphicsProfile: 'standard',
  opponentMonitoring: false,
  radarEnabled: false,
  espEnabled: false,
  // Safety defaults
  antiDetection: true,
  stealthOverlay: true,
  byteObfuscation: false,
  jitterEngine: true,
  antiRecording: false,
};
